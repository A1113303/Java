import java.util.*;

public class A1113303_0331{
    public static void main(String[] args){

        animal.showinfo();

        animal[] anm;
        anm=new animal[2];
        human[] hum;
        hum=new human[3];
        snow sn;
        int i;

        anm[0]=new animal("雪寶",1.1,52,100);
        anm[1]=new animal("驢子",1.5,99,200);
        hum[0]=new human("阿克",1.9,80,150,"男");
        hum[1]=new human("漢斯",1.8,78,130,"男");
        hum[2]=new human("安那",1.7,48,120,"女");
        sn=new snow("愛沙",1.7,50,120,"女","yes");

        for(i=0;i<2;i++){
            anm[i].show();
            System.out.print("\n");
        }
        for(i=0;i<3;i++){
            hum[i].show();
            System.out.print("\n");
        }
        sn.show();
        System.out.print("\n");
        

        Scanner sc=new Scanner(System.in);
        for(i=0;i<2;i++){
            System.out.println("請輸入"+anm[i].name+"所花時間(x值)：");
            anm[i].x=sc.nextInt();
            System.out.println("請輸入"+anm[i].name+"加速度(y值)：");
            anm[i].y=sc.nextDouble();
        }
        for(i=0;i<3;i++){
            System.out.println("請輸入"+hum[i].name+"所花時間(x值)：");
            hum[i].x=sc.nextInt();
            System.out.println("請輸入"+hum[i].name+"加速度(y值)：");
            hum[i].y=sc.nextDouble();
        }
        System.out.println("請輸入"+sn.name+"所花時間(x值)：");
        sn.x=sc.nextInt();
        System.out.println("請輸入"+sn.name+"加速度(y值)：");
        sn.y=sc.nextDouble();

        for(i=0;i<2;i++){
            if(anm[i].y==0){
                System.out.println(anm[i].name+"的距離為"+anm[i].distance(anm[i].x));
            }else{
                System.out.println(anm[i].name+"的距離為"+anm[i].distance(anm[i].x,anm[i].y));
            }
        }
        for(i=0;i<3;i++){
            if(hum[i].y==0){
                System.out.println(hum[i].name+"的距離為"+hum[i].distance(hum[i].x));
            }else{
                System.out.println(hum[i].name+"的距離為"+hum[i].distance(hum[i].x,hum[i].y));
            }
        }
        if(sn.y==0){
            System.out.println(sn.name+"的距離為"+sn.distance(sn.x));
        }else{
            System.out.println(sn.name+"的距離為"+sn.distance(sn.x,sn.y));
        }
        
        }
}