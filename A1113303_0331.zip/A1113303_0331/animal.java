 public class animal{

    String name;
    double height;
    int weight;
    int speed;
    int x;
    double y;

    animal(){
    }

    animal(String x,double y,int z,int h){
        this.name=x;
        this.height=y;
        this.weight=z;
        this.speed=h;
    }

    public static void showinfo(){
        System.out.println("歡迎進入冰雪奇緣系統");
    }

    void show(){
        System.out.print("姓名："+name+",身高："+height+",體重："+weight+",速度："+speed);
    }

    double distance(int x,double y){
        return this.speed*x*y;
    }

    int distance(int x){
        return this.speed*x;
    }

}

class human extends animal{

    String sex;

    human(String x,double y,int z,int h,String p){               
        super(x,y,z,h);
        this.sex=p;
    }

    void show(){
        super.show();
        System.out.print(",性別："+sex);
    }
}

class snow extends human{

    String skill;

    snow(String x,double y,int z,int h,String p,String s){
        super(x,y,z,h,p);
        this.skill=s;
    }

    void show(){
        super.show();
        System.out.print(",冰凍技能："+skill);
    }

    double distance(int x,double y){
        return this.speed*x*y*2;
    }

    int distance(int x){
        return this.speed*x*2;
    }

}